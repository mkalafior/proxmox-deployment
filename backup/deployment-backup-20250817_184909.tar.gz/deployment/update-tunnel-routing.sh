#!/bin/bash

# Update Cloudflare Tunnel Routing for New Deployments
# This script updates the tunnel configuration to route to newly deployed containers

set -euo pipefail

# Configuration
TUNNEL_NAME="${TUNNEL_NAME:-proxmox-main}"
DOMAIN="${CLOUDFLARE_DOMAIN:-}"
VM_IP_FILE="./vm_ip.txt"
CONFIG_FILE="/etc/cloudflared/config.yml"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Help function
show_help() {
    cat << EOF
Update Cloudflare Tunnel Routing

Usage: $0 [OPTIONS]

Options:
    -i, --ip IP_ADDRESS     Container IP address to route to
    -p, --port PORT         Port number (default: 3000)
    -s, --subdomain SUB     Subdomain to use (default: app)
    -d, --domain DOMAIN     Domain name (overrides CLOUDFLARE_DOMAIN)
    -f, --file FILE         File containing IP address (default: ./vm_ip.txt)
    -h, --help              Show this help message

Examples:
    $0 --ip 192.168.1.100 --port 3000 --subdomain myapp
    $0 --file ./vm_ip.txt --subdomain api --port 8080
    
Environment Variables:
    CLOUDFLARE_DOMAIN       Your Cloudflare domain
    TUNNEL_NAME            Tunnel name (default: proxmox-main)

EOF
}

# Parse command line arguments
parse_args() {
    CONTAINER_IP=""
    PORT="3000"
    SUBDOMAIN="app"
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            -i|--ip)
                CONTAINER_IP="$2"
                shift 2
                ;;
            -p|--port)
                PORT="$2"
                shift 2
                ;;
            -s|--subdomain)
                SUBDOMAIN="$2"
                shift 2
                ;;
            -d|--domain)
                DOMAIN="$2"
                shift 2
                ;;
            -f|--file)
                VM_IP_FILE="$2"
                shift 2
                ;;
            -h|--help)
                show_help
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
}

# Check prerequisites
check_prerequisites() {
    if [[ -z "$DOMAIN" ]]; then
        log_error "Please set CLOUDFLARE_DOMAIN environment variable or use --domain"
        exit 1
    fi
    
    if ! command -v cloudflared &> /dev/null; then
        log_error "cloudflared is not installed"
        exit 1
    fi
    
    # Check if we're on Proxmox server or local machine
    if [[ -f "$CONFIG_FILE" ]]; then
        PROXMOX_SERVER=true
        log_info "Running on Proxmox server"
    else
        PROXMOX_SERVER=false
        log_info "Running locally - will generate commands for Proxmox"
    fi
}

# Get container IP
get_container_ip() {
    if [[ -n "$CONTAINER_IP" ]]; then
        log_info "Using provided IP: $CONTAINER_IP"
        return 0
    fi
    
    if [[ -f "$VM_IP_FILE" ]]; then
        CONTAINER_IP=$(cat "$VM_IP_FILE" | tr -d '[:space:]')
        log_info "Read IP from $VM_IP_FILE: $CONTAINER_IP"
    else
        log_error "No IP provided and $VM_IP_FILE not found"
        log_info "Use --ip option or ensure $VM_IP_FILE exists"
        exit 1
    fi
    
    # Validate IP format
    if [[ ! $CONTAINER_IP =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        log_error "Invalid IP address format: $CONTAINER_IP"
        exit 1
    fi
}

# Generate tunnel configuration
generate_config() {
    local tunnel_uuid
    
    if [[ "$PROXMOX_SERVER" == true ]]; then
        # Get tunnel UUID from existing config or tunnel list
        if [[ -f "$CONFIG_FILE" ]]; then
            tunnel_uuid=$(grep "^tunnel:" "$CONFIG_FILE" | awk '{print $2}')
        else
            tunnel_uuid=$(cloudflared tunnel list | grep "$TUNNEL_NAME" | awk '{print $1}')
        fi
    else
        tunnel_uuid="<YOUR_TUNNEL_UUID>"
    fi
    
    cat > "/tmp/tunnel_config_update.yml" << EOF
tunnel: $tunnel_uuid
credentials-file: /root/.cloudflared/$tunnel_uuid.json

ingress:
  # Proxmox Web Interface
  - hostname: proxmox.$DOMAIN
    service: https://localhost:8006
    originRequest:
      noTLSVerify: true
      
  # Application: $SUBDOMAIN.$DOMAIN -> $CONTAINER_IP:$PORT
  - hostname: $SUBDOMAIN.$DOMAIN
    service: http://$CONTAINER_IP:$PORT
    originRequest:
      noTLSVerify: true
      
  # SSH access through Cloudflare
  - hostname: ssh.$DOMAIN
    service: ssh://localhost:22
    
  # Catch-all rule (required)
  - service: http_status:404
EOF

    log_info "Generated new tunnel configuration"
}

# Update tunnel configuration on Proxmox
update_proxmox_config() {
    if [[ "$PROXMOX_SERVER" != true ]]; then
        log_info "Not on Proxmox server - showing commands to run:"
        echo
        echo "Run these commands on your Proxmox server (root@$PROXMOX_HOST):"
        echo
        echo "# Backup current configuration"
        echo "cp $CONFIG_FILE ${CONFIG_FILE}.backup"
        echo
        echo "# Update configuration"
        cat "/tmp/tunnel_config_update.yml"
        echo
        echo "# Copy the above to $CONFIG_FILE"
        echo
        echo "# Set up DNS route"
        echo "cloudflared tunnel route dns $TUNNEL_NAME $SUBDOMAIN.$DOMAIN"
        echo
        echo "# Restart tunnel service"
        echo "systemctl restart cloudflared"
        echo
        echo "# Check status"
        echo "systemctl status cloudflared"
        echo
        return 0
    fi
    
    # Backup current configuration
    cp "$CONFIG_FILE" "${CONFIG_FILE}.backup.$(date +%Y%m%d_%H%M%S)"
    log_info "Backed up current configuration"
    
    # Update configuration
    cp "/tmp/tunnel_config_update.yml" "$CONFIG_FILE"
    log_info "Updated tunnel configuration"
    
    # Set up DNS route
    log_info "Setting up DNS route for $SUBDOMAIN.$DOMAIN"
    if cloudflared tunnel route dns "$TUNNEL_NAME" "$SUBDOMAIN.$DOMAIN"; then
        log_info "DNS route created successfully"
    else
        log_warn "DNS route may already exist or failed to create"
    fi
    
    # Restart tunnel service
    log_info "Restarting cloudflared service..."
    systemctl restart cloudflared
    
    sleep 3
    
    if systemctl is-active --quiet cloudflared; then
        log_info "✓ Cloudflared service restarted successfully"
    else
        log_error "✗ Failed to restart cloudflared service"
        log_info "Check logs with: journalctl -u cloudflared -f"
        
        # Restore backup
        cp "${CONFIG_FILE}.backup.$(date +%Y%m%d_%H%M%S)" "$CONFIG_FILE"
        systemctl restart cloudflared
        log_info "Restored previous configuration"
        exit 1
    fi
}

# Test the new route
test_route() {
    log_info "Testing new route..."
    
    # Test local connectivity first
    if curl -s --connect-timeout 5 "http://$CONTAINER_IP:$PORT" > /dev/null; then
        log_info "✓ Container is accessible locally at $CONTAINER_IP:$PORT"
    else
        log_warn "⚠ Container may not be running at $CONTAINER_IP:$PORT"
    fi
    
    log_info "New route configured:"
    log_info "  URL: https://$SUBDOMAIN.$DOMAIN"
    log_info "  Target: $CONTAINER_IP:$PORT"
    log_info ""
    log_warn "Note: DNS propagation may take a few minutes"
    log_info "Monitor with: journalctl -u cloudflared -f"
}

# Main execution
main() {
    log_info "Updating Cloudflare Tunnel routing..."
    
    parse_args "$@"
    check_prerequisites
    get_container_ip
    
    log_info "Configuration:"
    log_info "  Domain: $DOMAIN"
    log_info "  Subdomain: $SUBDOMAIN"
    log_info "  Container IP: $CONTAINER_IP"
    log_info "  Port: $PORT"
    log_info "  Full URL: https://$SUBDOMAIN.$DOMAIN"
    
    generate_config
    update_proxmox_config
    test_route
    
    log_info "Tunnel routing update completed!"
}

# Cleanup on exit
cleanup() {
    rm -f "/tmp/tunnel_config_update.yml"
}
trap cleanup EXIT

# Run main function
main "$@"
