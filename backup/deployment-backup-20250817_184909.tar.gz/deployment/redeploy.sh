#!/bin/bash

# Code Redeployment Script for Hello World Bun App
# Usage: ./redeploy.sh

set -e

echo "🔄 Hello World Bun App - Code Redeployment"
echo "=========================================="

# Check if we're in the right directory
if [[ ! -f "redeploy.yml" ]]; then
    echo "❌ Error: Please run this script from the deployment directory"
    echo "   cd deployment && ./redeploy.sh"
    exit 1
fi

# Check if initial deployment exists
if [[ ! -f "vm_ip.txt" ]]; then
    echo "❌ Error: No existing deployment found"
    echo ""
    echo "Please run the initial deployment first:"
    echo "   ./deploy.sh"
    exit 1
fi

# Check if SSH key exists
if [[ ! -f "$HOME/.ssh/id_proxmox" ]]; then
    echo "❌ Error: Dedicated Proxmox SSH key not found"
    echo ""
    echo "SSH key missing. Please run initial deployment:"
    echo "   ./deploy.sh"
    exit 1
fi

# Check if ansible is installed
if ! command -v ansible-playbook &> /dev/null; then
    echo "❌ Error: Ansible is not installed"
    echo ""
    echo "Install Ansible:"
    echo "   macOS: brew install ansible"
    echo "   Ubuntu: apt install ansible"
    echo "   pip: pip3 install ansible"
    exit 1
fi

# Get VM info
VM_IP=$(cat vm_ip.txt)

echo "✅ Environment checks passed"

echo ""
echo "📋 Redeployment Plan:"
echo "   Target VM: $VM_IP"
echo "   Application: Hello World Bun App"
echo "   Strategy: Rolling update with automatic rollback"
echo "   Backup: Automatic backup before update"
echo ""

# Confirm redeployment
read -p "🤔 Do you want to proceed with code redeployment? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Redeployment cancelled"
    exit 1
fi

echo ""
echo "🔨 Building application locally with Bun..."
cd ..
if command -v bun &> /dev/null; then
    if ! bun run build; then
        echo "❌ Local build failed. Please fix build errors before redeploying."
        exit 1
    fi
    echo "✅ Local build successful!"
else
    echo "⚠️  Bun not found locally, will build on server"
fi
cd deployment

echo ""
echo "🚀 Starting code redeployment..."
echo "   This will:"
echo "   1. Stop the service"
echo "   2. Backup current version"
echo "   3. Deploy new code"
echo "   4. Rebuild on server"
echo "   5. Restart service"
echo "   6. Verify deployment"

# Run redeployment
ansible-playbook redeploy.yml -v

# Check if redeployment was successful
if [[ $? -eq 0 ]]; then
    echo ""
    echo "🎉 Code redeployment completed successfully!"
    echo ""
    echo "📊 Your updated Hello World Bun app is now running at:"
    echo "   VM IP: $VM_IP"
    echo "   Application URL: http://$VM_IP:3000"
    echo "   Health Check: http://$VM_IP:3000/health"
    echo "   API Info: http://$VM_IP:3000/api/info"
    echo ""
    echo "🔧 Management commands:"
    echo "   Check status: ansible-playbook manage.yml --tags=status"
    echo "   View logs:    ansible-playbook manage.yml --tags=logs"
    echo "   Restart:      ansible-playbook manage.yml --tags=restart"
    echo "   System info:  ansible-playbook manage.yml --tags=system"
    echo ""
    echo "🔍 SSH into VM:"
    echo "   ssh -i ~/.ssh/id_proxmox root@$VM_IP"
    echo ""
    echo "💻 Your Bun application is running with the latest code!"
else
    echo ""
    echo "❌ Redeployment failed!"
    echo "   The system attempted automatic rollback."
    echo "   Check the error messages above for details."
    echo ""
    echo "🔍 Troubleshooting:"
    echo "   Check logs: ansible-playbook manage.yml --tags=logs"
    echo "   SSH to VM: ssh -i ~/.ssh/id_proxmox root@$VM_IP"
    exit 1
fi
