# Cloudflare Tunnel Setup for Proxmox Access

This guide will help you set up Cloudflare Tunnels to securely access your Proxmox server and deployed applications without opening ports on your router.

## Prerequisites

- A domain managed by Cloudflare
- Administrative access to your Proxmox server (192.168.1.99)
- Cloudflare account with appropriate permissions

## Overview

We'll set up tunnels for:
1. **Proxmox Web Interface** - Access Proxmox UI securely
2. **Deployed Applications** - Access your containerized apps
3. **SSH Access** - Secure remote access to containers

## Step 1: Install cloudflared on Proxmox

SSH into your Proxmox server and install the Cloudflare Tunnel daemon:

```bash
# SSH into Proxmox
ssh root@192.168.1.99

# Download and install cloudflared
wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared-linux-amd64.deb
```

## Step 2: Authenticate with Cloudflare

```bash
# Authenticate cloudflared with your Cloudflare account
cloudflared tunnel login
```

This will provide a URL - open it in your browser and log in to authorize the tunnel.

## Step 3: Create Tunnels

### Create Main Tunnel for Proxmox
```bash
# Create a tunnel for Proxmox access
cloudflared tunnel create proxmox-main
```

Note the UUID returned - you'll need it for configuration.

## Step 4: Configure the Tunnel

Create the tunnel configuration file:

```bash
sudo mkdir -p /etc/cloudflared
sudo nano /etc/cloudflared/config.yml
```

Add this configuration (replace `<UUID>` with your tunnel UUID and `<your-domain>` with your domain):

```yaml
tunnel: <UUID>
credentials-file: /root/.cloudflared/<UUID>.json

ingress:
  # Proxmox Web Interface
  - hostname: proxmox.<your-domain>
    service: https://localhost:8006
    originRequest:
      noTLSVerify: true
      
  # Container applications (will be dynamically updated)
  - hostname: app.<your-domain>
    service: http://192.168.1.99:3000
    originRequest:
      noTLSVerify: true
      
  # Catch-all rule (required)
  - service: http_status:404
```

## Step 5: Set Up DNS Routes

```bash
# Route DNS for Proxmox
cloudflared tunnel route dns proxmox-main proxmox.<your-domain>

# Route DNS for applications
cloudflared tunnel route dns proxmox-main app.<your-domain>
```

## Step 6: Run Tunnel as a Service

```bash
# Install and start the service
cloudflared service install
sudo systemctl enable --now cloudflared

# Check service status
sudo systemctl status cloudflared
```

## Step 7: Security Hardening (Optional but Recommended)

### Block Direct Access to Proxmox Web Interface
```bash
# Block external access to Proxmox web interface
sudo iptables -A INPUT -p tcp --dport 8006 ! -s 127.0.0.1 -j DROP

# Save iptables rules
sudo apt install iptables-persistent -y
sudo iptables-save > /etc/iptables/rules.v4
```

### Configure Cloudflare Access (Optional)
Set up Cloudflare Access for additional authentication layers through the Cloudflare dashboard.

## Testing Access

1. **Proxmox Web Interface**: `https://proxmox.<your-domain>`
2. **Applications**: `https://app.<your-domain>`

## Dynamic Application Routing

For applications deployed via your Ansible setup, you can dynamically update the tunnel configuration to route to specific container IPs.

### Update Configuration for Specific Container
When you deploy a new container, update the tunnel config:

```bash
# Get container IP from your deployment
CONTAINER_IP=$(cat /path/to/your/deployment/vm_ip.txt)

# Update tunnel config to route to specific container
sudo nano /etc/cloudflared/config.yml
```

Update the app section:
```yaml
  - hostname: app.<your-domain>
    service: http://${CONTAINER_IP}:3000
```

Then restart the tunnel:
```bash
sudo systemctl restart cloudflared
```

## Troubleshooting

### Check Tunnel Status
```bash
# Check if tunnel is running
sudo systemctl status cloudflared

# View tunnel logs
sudo journalctl -u cloudflared -f

# Test tunnel connectivity
cloudflared tunnel info proxmox-main
```

### Common Issues

1. **SSL Certificate Errors**: Ensure `noTLSVerify: true` is set for self-signed certificates
2. **DNS Not Resolving**: Check that DNS routes are properly configured in Cloudflare
3. **Service Not Starting**: Check cloudflared logs for authentication issues

### Manual Testing
Test tunnel connectivity manually:
```bash
# Test tunnel without service
cloudflared tunnel --config /etc/cloudflared/config.yml run
```

## Security Considerations

1. **Use Cloudflare Access** for additional authentication
2. **Enable Cloudflare WAF** for application protection
3. **Monitor Access Logs** through Cloudflare dashboard
4. **Regular Token Rotation** for enhanced security
5. **Network Segmentation** - consider isolating Proxmox network

## Next Steps

- Set up Cloudflare Access policies
- Configure application-specific routing
- Set up monitoring and alerting
- Consider using Cloudflare Teams for enhanced security
