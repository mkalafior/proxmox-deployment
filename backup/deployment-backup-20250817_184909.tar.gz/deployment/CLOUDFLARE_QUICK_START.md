# Cloudflare Tunnel Quick Start Guide

Quick setup guide for accessing your Proxmox and deployed applications through Cloudflare Tunnels.

## Prerequisites

- ✅ Domain managed by Cloudflare
- ✅ Proxmox server accessible (currently: 192.168.1.99)
- ✅ Cloudflare account with tunnel permissions

## Step 1: Set Environment Variables

```bash
# Required: Your Cloudflare domain
export CLOUDFLARE_DOMAIN=yourdomain.com

# Optional: Customize subdomains
export PROXMOX_SUBDOMAIN=proxmox    # Default: proxmox
export APP_SUBDOMAIN=app            # Default: app
export SSH_SUBDOMAIN=ssh            # Default: ssh
export TUNNEL_NAME=proxmox-main     # Default: proxmox-main
```

## Step 2: Automated Setup (Recommended)

### Option A: Full Automated Setup
```bash
# Copy setup script to Proxmox
scp ./setup-cloudflare-tunnel.sh root@192.168.1.99:/tmp/

# Run automated setup on Proxmox
ssh root@192.168.1.99 "CLOUDFLARE_DOMAIN=$CLOUDFLARE_DOMAIN /tmp/setup-cloudflare-tunnel.sh"
```

### Option B: Using Ansible
```bash
# Generate setup files
ansible-playbook cloudflare-tunnel.yml

# Copy and run on Proxmox
scp ./proxmox-tunnel-commands.sh root@192.168.1.99:/tmp/
ssh root@192.168.1.99 "/tmp/proxmox-tunnel-commands.sh"
```

## Step 3: Access Your Services

After setup, access your services at:

- **Proxmox Web Interface**: `https://proxmox.yourdomain.com`
- **Applications**: `https://app.yourdomain.com`
- **SSH Access**: `ssh.yourdomain.com`

## Step 4: Deploy and Route Applications

### After deploying a container:

```bash
# Option 1: Automated routing update
./update-tunnel-routing.sh --ip $(cat vm_ip.txt) --port 3000 --subdomain myapp

# Option 2: Use Ansible to generate commands
ansible-playbook cloudflare-tunnel.yml

# Option 3: Manual update
scp ./tunnel-update-commands.sh root@192.168.1.99:/tmp/
ssh root@192.168.1.99 "/tmp/tunnel-update-commands.sh"
```

## Complete Deployment Workflow

```bash
# 1. Set up environment
export CLOUDFLARE_DOMAIN=yourdomain.com
source env.proxmox

# 2. Deploy application
./deploy.sh

# 3. Update tunnel routing for the new app
./update-tunnel-routing.sh --file vm_ip.txt --subdomain myapp

# Your app is now accessible at: https://myapp.yourdomain.com
```

## Troubleshooting

### Check Tunnel Status
```bash
# On Proxmox server
systemctl status cloudflared
journalctl -u cloudflared -f

# Check tunnel info
cloudflared tunnel info proxmox-main
```

### Common Issues

1. **DNS not resolving**: Wait 2-5 minutes for DNS propagation
2. **502 Bad Gateway**: Check if target service is running
3. **SSL errors**: Ensure `noTLSVerify: true` for self-signed certs
4. **Service not starting**: Check authentication and credentials

### Test Connectivity
```bash
# Test local container
curl -I http://$(cat vm_ip.txt):3000

# Test through tunnel (after DNS propagation)
curl -I https://app.yourdomain.com
```

## Security Notes

- Direct Proxmox access (port 8006) is blocked after setup
- Use Cloudflare Access for additional authentication
- Monitor access logs in Cloudflare dashboard
- Consider enabling Cloudflare WAF for protection

## File Structure

```
deployment/
├── setup-cloudflare-tunnel.sh          # Automated setup script
├── update-tunnel-routing.sh             # Update routing for new apps
├── cloudflare-tunnel.yml                # Ansible integration
├── cloudflare-tunnel-setup.md           # Detailed setup guide
├── CLOUDFLARE_QUICK_START.md            # This file
└── templates/
    ├── cloudflare-config.yml.j2         # Tunnel config template
    ├── proxmox-tunnel-commands.sh.j2    # Setup commands template
    └── tunnel-update-commands.sh.j2     # Update commands template
```

## Support

- [Detailed Setup Guide](./cloudflare-tunnel-setup.md)
- [Cloudflare Tunnel Documentation](https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/)
- Check logs: `journalctl -u cloudflared -f`
