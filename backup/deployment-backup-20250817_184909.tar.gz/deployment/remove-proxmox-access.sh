#!/bin/bash

# Script to remove Proxmox access from Cloudflare Tunnel
# Keeps only application routing active

set -euo pipefail

# Configuration
DOMAIN="${CLOUDFLARE_DOMAIN:-}"
TUNNEL_NAME="${TUNNEL_NAME:-proxmox-main}"
PROXMOX_HOST="${PROXMOX_HOST:-192.168.1.99}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root on the Proxmox server"
        exit 1
    fi
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    if [[ -z "$DOMAIN" ]]; then
        log_error "Please set CLOUDFLARE_DOMAIN environment variable"
        log_info "Example: export CLOUDFLARE_DOMAIN=yourdomain.com"
        exit 1
    fi
    
    if ! command -v cloudflared &> /dev/null; then
        log_error "cloudflared is not installed"
        exit 1
    fi
    
    log_info "Prerequisites check passed"
}

# Get tunnel UUID
get_tunnel_uuid() {
    log_info "Getting tunnel UUID..."
    TUNNEL_UUID=$(cloudflared tunnel list | grep "$TUNNEL_NAME" | awk '{print $1}')
    
    if [[ -z "$TUNNEL_UUID" ]]; then
        log_error "Tunnel $TUNNEL_NAME not found"
        exit 1
    fi
    
    log_info "Found tunnel UUID: $TUNNEL_UUID"
}

# Remove Proxmox DNS route
remove_proxmox_dns() {
    log_info "Removing Proxmox DNS route..."
    
    if cloudflared tunnel route dns --overwrite-dns "$TUNNEL_NAME" "proxmox.$DOMAIN" &> /dev/null; then
        # If that doesn't work, try deleting the route
        cloudflared tunnel route delete "proxmox.$DOMAIN" || log_warn "Could not delete DNS route for proxmox.$DOMAIN"
    fi
    
    log_info "Proxmox DNS route removal attempted"
}

# Remove SSH DNS route
remove_ssh_dns() {
    log_info "Removing SSH DNS route..."
    
    if cloudflared tunnel route dns --overwrite-dns "$TUNNEL_NAME" "ssh.$DOMAIN" &> /dev/null; then
        # If that doesn't work, try deleting the route
        cloudflared tunnel route delete "ssh.$DOMAIN" || log_warn "Could not delete DNS route for ssh.$DOMAIN"
    fi
    
    log_info "SSH DNS route removal attempted"
}

# Update tunnel configuration
update_tunnel_config() {
    log_info "Updating tunnel configuration..."
    
    # Backup existing config
    cp /etc/cloudflared/config.yml /etc/cloudflared/config.yml.backup
    log_info "Backed up existing config to config.yml.backup"
    
    # Create new config with only app routing
    cat > /etc/cloudflared/config.yml << EOF
tunnel: $TUNNEL_UUID
credentials-file: /root/.cloudflared/$TUNNEL_UUID.json

ingress:
  # Application routing only
  - hostname: app.$DOMAIN
    service: http://$PROXMOX_HOST:3000
    originRequest:
      noTLSVerify: true
    
  # Catch-all rule (required)
  - service: http_status:404
EOF
    
    log_info "Updated tunnel configuration - removed Proxmox and SSH routing"
}

# Restart cloudflared service
restart_service() {
    log_info "Restarting cloudflared service..."
    
    systemctl restart cloudflared
    sleep 5
    
    if systemctl is-active --quiet cloudflared; then
        log_info "Cloudflared service restarted successfully"
    else
        log_error "Failed to restart cloudflared service"
        log_info "Check logs with: journalctl -u cloudflared -f"
        exit 1
    fi
}

# Ensure direct Proxmox access is available
ensure_proxmox_access() {
    log_info "Ensuring direct Proxmox access..."
    
    # Remove any DROP rules for port 8006 to ensure access
    iptables -D INPUT -p tcp --dport 8006 -j DROP 2>/dev/null || log_info "No blocking rules found for port 8006"
    
    # Save iptables rules
    if command -v iptables-save &> /dev/null; then
        iptables-save > /etc/iptables/rules.v4
        log_info "Direct Proxmox access is available on port 8006"
    else
        log_info "Direct Proxmox access should be available on port 8006"
    fi
}

# Test configuration
test_configuration() {
    log_info "Testing new configuration..."
    
    # Test tunnel status
    if cloudflared tunnel info "$TUNNEL_NAME" &> /dev/null; then
        log_info "✓ Tunnel information accessible"
    else
        log_warn "⚠ Could not get tunnel information"
    fi
    
    # Test service status
    if systemctl is-active --quiet cloudflared; then
        log_info "✓ Cloudflared service is active"
    else
        log_error "✗ Cloudflared service is not active"
    fi
    
    log_info "Configuration updated successfully!"
    log_info ""
    log_info "Available services:"
    log_info "  Apps: https://app.$DOMAIN"
    log_info "  Proxmox Direct: https://$PROXMOX_HOST:8006"
    log_info ""
    log_warn "Note: DNS changes may take a few minutes to propagate"
    log_info "The proxmox.$DOMAIN and ssh.$DOMAIN subdomains will no longer work"
}

# Main execution
main() {
    log_info "Removing Proxmox access from Cloudflare Tunnel..."
    log_info "Domain: $DOMAIN"
    log_info "Tunnel Name: $TUNNEL_NAME"
    
    check_root
    check_prerequisites
    get_tunnel_uuid
    remove_proxmox_dns
    remove_ssh_dns
    update_tunnel_config
    restart_service
    ensure_proxmox_access
    test_configuration
    
    log_info "Proxmox access removal completed successfully!"
}

# Run main function
main "$@"
