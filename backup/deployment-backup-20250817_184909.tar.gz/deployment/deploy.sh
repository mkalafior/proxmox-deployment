#!/bin/bash

# Proxmox Deployment Script for Hello World Bun App
# Usage: ./deploy.sh

set -e

echo "🚀 Hello World Bun App - Proxmox Deployment"
echo "============================================"

# Check if we're in the right directory
if [[ ! -f "deploy.yml" ]]; then
    echo "❌ Error: Please run this script from the deployment directory"
    echo "   cd deployment && ./deploy.sh"
    exit 1
fi

# Load environment variables from env.proxmox if it exists
if [[ -f "../env.proxmox" ]]; then
    source ../env.proxmox
    echo "✅ Loaded environment from env.proxmox"
else
    echo "❌ env.proxmox file not found"
    echo "   Please create env.proxmox file in the root directory"
    exit 1
fi

# Check required environment variables
if [[ -z "$PROXMOX_HOST" ]]; then
    echo "❌ Error: PROXMOX_HOST environment variable is not set"
    echo ""
    echo "Please set your Proxmox server details:"
    echo "   export PROXMOX_HOST=\"192.168.1.100\""
    echo "   export PROXMOX_USER=\"root@pam\""
    echo "   export PROXMOX_PASSWORD=\"your_password\""
    echo "   export PROXMOX_NODE=\"proxmox\""
    exit 1
fi

# Check authentication - either password OR token must be set
if [[ -z "$PROXMOX_PASSWORD" && (  -z "$TOKEN_ID" || -z "$TOKEN_SECRET" ) ]]; then
    echo "❌ Error: No authentication configured"
    echo ""
    echo "Please configure either:"
    echo "  Option 1 - Username/Password:"
    echo "    export PROXMOX_PASSWORD=\"your_password\""
    echo ""
    echo "  Option 2 - API Token (recommended):"
    echo "    export TOKEN_ID=\"root@pam!your_token_name\""
    echo "    export TOKEN_SECRET=\"your_token_secret\""
    echo ""
    echo "Check your env.proxmox file for current settings."
    exit 1
fi

echo "✅ Authentication: $(
    if [[ -n "$TOKEN_ID" && -n "$TOKEN_SECRET" ]]; then
        echo "API Token ($TOKEN_ID)"
    else
        echo "Username/Password ($PROXMOX_USER)"
    fi
)"

# Check if ansible is installed
if ! command -v ansible-playbook &> /dev/null; then
    echo "❌ Error: Ansible is not installed"
    echo ""
    echo "Install Ansible:"
    echo "   macOS: brew install ansible"
    echo "   Ubuntu: apt install ansible"
    echo "   pip: pip3 install ansible"
    exit 1
fi

# Check if dedicated Proxmox SSH key exists or create one
SSH_KEY_PATH="$HOME/.ssh/id_proxmox"
if [[ ! -f "${SSH_KEY_PATH}.pub" ]]; then
    echo ""
    echo "🔑 Dedicated Proxmox SSH key not found at ${SSH_KEY_PATH}"
    echo "   Creating new SSH key for Proxmox deployment..."
    echo ""
    read -p "   Create SSH key automatically? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        ssh-keygen -t ed25519 -f "${SSH_KEY_PATH}" -N "" -C "proxmox-hello-world-$(date +%Y%m%d)"
        if [[ $? -ne 0 ]]; then
            echo "❌ Failed to create SSH key"
            exit 1
        fi
        echo "✅ Dedicated Proxmox SSH key created at ${SSH_KEY_PATH}"
    else
        echo "❌ SSH key is required for deployment"
        echo "   Create one manually: ssh-keygen -t ed25519 -f ${SSH_KEY_PATH}"
        exit 1
    fi
fi

echo "✅ Environment checks passed"

# Check basic Proxmox connectivity (skip template API check due to auth issues)
echo ""
echo "🔍 Checking Proxmox connectivity..."
if ! ping -c 1 $PROXMOX_HOST >/dev/null 2>&1; then
    echo "❌ Cannot reach Proxmox host $PROXMOX_HOST"
    exit 1
fi

# Test basic auth
if ! curl -k -s -X POST https://$PROXMOX_HOST:8006/api2/json/access/ticket \
    -d "username=$PROXMOX_USER" -d "password=$PROXMOX_PASSWORD" | grep -q '"ticket"'; then
    echo "❌ Cannot authenticate with Proxmox API"
    echo "   Please verify credentials in env.proxmox"
    exit 1
fi

echo "✅ Proxmox connectivity confirmed"
echo "✅ Using template: local:vztmpl/ubuntu-24.04-standard_24.04-2_amd64.tar.zst"

# Set the correct template for this deployment
export VM_TEMPLATE="local:vztmpl/ubuntu-24.04-standard_24.04-2_amd64.tar.zst"

# Install required collections
echo ""
echo "📦 Installing Ansible collections..."
ansible-galaxy collection install -r requirements.yml --force

# Validate playbook syntax
echo ""
echo "🔍 Validating playbook syntax..."
ansible-playbook deploy.yml --syntax-check

# Show deployment plan
echo ""
echo "🎯 Deployment Plan:"
echo "   Proxmox Host: ${PROXMOX_HOST}"
echo "   VM ID: ${VM_ID:-200}"
echo "   VM Name: hello-world-bun-app"
echo "   Template: ${VM_TEMPLATE:-ubuntu-22.04-standard}"
echo "   Cores: 2, Memory: 2GB, Disk: 20GB"
echo "   Application: Bun Hello World App"
echo "   SSH Key: ${SSH_KEY_PATH}.pub (dedicated Proxmox key)"
echo ""

# Confirm deployment
read -p "🤔 Do you want to proceed with deployment? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Deployment cancelled"
    exit 1
fi

echo ""
echo "🚀 Starting deployment..."
echo "   This will take 5-10 minutes..."

# Run deployment
ansible-playbook deploy.yml -v

# Check if deployment was successful
if [[ $? -eq 0 ]]; then
    echo ""
    echo "🎉 Deployment completed successfully!"
    echo ""
    
    if [[ -f "vm_ip.txt" ]]; then
        VM_IP=$(cat vm_ip.txt)
        echo "📊 Your Hello World Bun app is now running at:"
        echo "   VM IP: $VM_IP"
        echo "   Application URL: http://$VM_IP:3000"
        echo "   Health Check: http://$VM_IP:3000/health"
        echo "   API Info: http://$VM_IP:3000/api/info"
        echo ""
        
        echo "🔧 Management commands:"
        echo "   Check status: ansible-playbook manage.yml --tags=status"
        echo "   View logs:    ansible-playbook manage.yml --tags=logs"
        echo "   Restart:      ansible-playbook manage.yml --tags=restart"
        echo "   System info:  ansible-playbook manage.yml --tags=system"
        echo ""
        echo "🔍 SSH into VM:"
        echo "   ssh -i ~/.ssh/id_proxmox root@$VM_IP"
        echo ""
        echo "🔄 Update application code:"
        echo "   ./redeploy.sh"
        echo ""
        echo "🧹 Clean up deployment:"
        echo "   ./cleanup.sh"
        echo ""
        echo "💡 Your Bun application is now running in a Proxmox container!"
    fi
else
    echo ""
    echo "❌ Deployment failed!"
    echo "   Check the error messages above for details"
    exit 1
fi
