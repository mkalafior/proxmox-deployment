#!/bin/bash

# Cleanup Script for Hello World Bun App Proxmox Deployment
# Usage: ./cleanup.sh

set -e

echo "🧹 Hello World Bun App - Cleanup Deployment"
echo "============================================"

# Check if we're in the right directory
if [[ ! -f "deploy.yml" ]]; then
    echo "❌ Error: Please run this script from the deployment directory"
    echo "   cd deployment && ./cleanup.sh"
    exit 1
fi

# Check required environment variables
if [[ -z "$PROXMOX_HOST" ]]; then
    echo "❌ Error: PROXMOX_HOST environment variable is not set"
    echo ""
    echo "Please set your Proxmox server details:"
    echo "   export PROXMOX_HOST=\"192.168.1.100\""
    echo "   export PROXMOX_PASSWORD=\"your_password\""
    exit 1
fi

if [[ -z "$PROXMOX_PASSWORD" ]]; then
    echo "❌ Error: PROXMOX_PASSWORD environment variable is not set"
    exit 1
fi

# Check if ansible is installed
if ! command -v ansible &> /dev/null; then
    echo "❌ Error: Ansible is not installed"
    echo ""
    echo "Install Ansible:"
    echo "   macOS: brew install ansible"
    echo "   Ubuntu: apt install ansible"
    echo "   pip: pip3 install ansible"
    exit 1
fi

# Show what will be cleaned up
echo ""
echo "🗑️  This will remove the following resources:"
echo "   • Proxmox Container: hello-world-bun-app (VM ID: ${VM_ID:-200})"
echo "   • All application data and logs"
echo "   • Local deployment files (vm_ip.txt)"
echo ""

# Get VM IP if available
VM_IP=""
if [[ -f "vm_ip.txt" ]]; then
    VM_IP=$(cat vm_ip.txt)
    echo "   • Target VM IP: $VM_IP"
fi

echo ""
echo "⚠️  WARNING: This action cannot be undone!"
echo ""

# Confirm cleanup
read -p "🤔 Are you sure you want to delete the deployment? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Cleanup cancelled"
    exit 1
fi

echo ""
echo "🗑️  Starting cleanup..."

# Stop the container first (if it exists and is accessible)
if [[ -n "$VM_IP" ]] && [[ -f "$HOME/.ssh/id_proxmox" ]]; then
    echo "   Stopping application service..."
    ansible all -i "${VM_IP}," -u root --private-key="$HOME/.ssh/id_proxmox" \
        -m systemd -a "name=hello-world-bun-app state=stopped" \
        --ssh-extra-args="-o ConnectTimeout=10 -o StrictHostKeyChecking=no" \
        2>/dev/null || echo "   (Service stop failed or VM not accessible)"
fi

# Delete the Proxmox container
echo "   Deleting Proxmox container..."
ansible localhost -m community.general.proxmox \
    -a "api_host=$PROXMOX_HOST api_user=${PROXMOX_USER:-root@pam} api_password=$PROXMOX_PASSWORD validate_certs=false vmid=${VM_ID:-200} state=absent force=true" \
    2>/dev/null || echo "   (Container may not exist or already deleted)"

# Remove local files
echo "   Cleaning up local files..."
if [[ -f "vm_ip.txt" ]]; then
    rm -f vm_ip.txt
    echo "   ✅ Removed vm_ip.txt"
fi

# Clean up any temporary files
if [[ -f "/tmp/vm_root_password" ]]; then
    rm -f "/tmp/vm_root_password"
    echo "   ✅ Removed temporary password file"
fi

echo ""
echo "✅ Cleanup completed successfully!"
echo ""
echo "🚀 To deploy again, run:"
echo "   ./deploy.sh"
echo ""
echo "💡 The dedicated Proxmox SSH key ($HOME/.ssh/id_proxmox) has been preserved for future deployments."
