# Proxmox Deployment for Hello World Bun App

This directory contains all the Ansible automation for deploying the Hello World Bun application to Proxmox Virtual Environment.

## 🚀 Quick Start

### Prerequisites

1. **Proxmox VE Server** running and accessible
2. **Ansible** installed on your local machine
3. **Container template** available in Proxmox (Ubuntu 22.04 recommended)
4. **SSH access** configured

### Environment Setup

```bash
# Set required environment variables
export PROXMOX_HOST="192.168.1.100"          # Your Proxmox server IP
export PROXMOX_USER="root@pam"               # Proxmox username (optional, defaults to root@pam)
export PROXMOX_PASSWORD="your_password"       # Proxmox password
export PROXMOX_NODE="proxmox"                # Proxmox node name (optional, defaults to 'proxmox')

# Optional: Customize VM settings
export VM_ID="200"                           # VM ID (defaults to 200)
export VM_TEMPLATE="local:vztmpl/ubuntu-22.04-standard_22.04-1_amd64.tar.zst"
```

### Deployment Commands

```bash
# Navigate to deployment directory
cd deployment

# Deploy application (creates VM and installs app)
./deploy.sh

# Update application code (keeps VM, updates app)
./redeploy.sh

# Remove everything (deletes VM and cleans up)
./cleanup.sh
```

## 📁 File Structure

```
deployment/
├── deploy.sh              # Main deployment script
├── redeploy.sh            # Code update script  
├── cleanup.sh             # Cleanup script
├── deploy.yml             # Main Ansible playbook
├── redeploy.yml           # Code redeployment playbook
├── manage.yml             # Management tasks playbook
├── ansible.cfg            # Ansible configuration
├── requirements.yml       # Ansible Galaxy requirements
├── inventory.yml          # Dynamic inventory
├── group_vars/
│   └── all.yml           # Configuration variables
└── templates/
    ├── hello-world-bun-app.service.j2  # Systemd service template
    └── env.j2                          # Environment file template
```

## ⚙️ Configuration

Edit `group_vars/all.yml` to customize:

- **VM specifications** (CPU, memory, disk size)
- **Network configuration** (bridge, IP assignment)
- **Application settings** (port, environment variables)
- **Security settings** (firewall ports, SSH keys)

## 🔧 Management

After deployment, manage your application with:

```bash
# Check application status
ansible-playbook manage.yml --tags=status

# View application logs
ansible-playbook manage.yml --tags=logs

# Restart application
ansible-playbook manage.yml --tags=restart

# View system information
ansible-playbook manage.yml --tags=system

# Get health check
ansible-playbook manage.yml --tags=health
```

## 🌐 Accessing Your Application

After successful deployment:

- **Web Interface**: `http://[VM_IP]:3000`
- **Health Check**: `http://[VM_IP]:3000/health`
- **API Info**: `http://[VM_IP]:3000/api/info`
- **SSH Access**: `ssh -i ~/.ssh/id_rsa root@[VM_IP]`

## 📊 What Gets Deployed

1. **Proxmox LXC Container** with Ubuntu 22.04
2. **Bun runtime** (latest version)
3. **Application code** with dependencies
4. **Systemd service** for automatic startup
5. **Firewall configuration** (UFW)
6. **Application user** (non-root execution)

## 🛡️ Security Features

- **Unprivileged containers** for better isolation
- **Dedicated application user** (non-root)
- **Firewall rules** (only necessary ports open)
- **SSH key authentication** (no password login)
- **Secure file permissions**

## 🔍 Troubleshooting

### Container Creation Issues

```bash
# Check Proxmox API connectivity
curl -k https://$PROXMOX_HOST:8006/api2/json/version

# Verify templates are available
# Login to Proxmox web interface → Node → Container Templates
```

### Application Issues

```bash
# SSH into the container
ssh -i ~/.ssh/id_rsa root@[VM_IP]

# Check service status
systemctl status hello-world-bun-app

# View logs
journalctl -u hello-world-bun-app -f

# Test Bun installation
bun --version
```

### Network Issues

```bash
# Check container networking
ip addr show
ping 8.8.8.8

# Check firewall status
ufw status
```

## 📋 Requirements

### Local Machine

- Ansible >= 2.9
- Python >= 3.8
- SSH client

### Proxmox Server

- Proxmox VE >= 6.0
- Container templates (download via Proxmox web interface)
- Network bridge configured (vmbr0)
- Sufficient resources (2 CPU, 2GB RAM, 20GB storage)

## 🔄 Update Process

The redeployment process:

1. **Stops** the running application
2. **Backs up** current application files
3. **Deploys** new code
4. **Installs** updated dependencies
5. **Restarts** the application
6. **Verifies** successful deployment
7. **Rolls back** automatically if deployment fails

## 💡 Tips

- **Container Templates**: Download Ubuntu 22.04 template from Proxmox web interface
- **Resource Planning**: Start with 2 CPU/2GB RAM, scale as needed
- **Backup Strategy**: Consider enabling Proxmox backup schedules
- **Monitoring**: Use the management playbook for routine checks
- **Network**: Ensure your Proxmox bridge has internet access for package installation
